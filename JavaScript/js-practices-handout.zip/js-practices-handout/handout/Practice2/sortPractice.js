'use strict'

function sort(input) {
  return input.sort((a,b) => a-b); // Remove this line and change to your own algorithm
}

module.exports = sort
